 //sign in and sign up
    function signin() {
        var userName = document.getElementById("signinusername");
        var passWord = document.getElementById("signinpassword");
        
        
        if (userName.value.trim() == ""){
            userName.style.border = "1px solid red";
            document.getElementById("labeluser").style.visibility="visible";
            return false;
        }

        else if (passWord.value.trim() == ""){
            passWord.style.border = "1px solid red";
            document.getElementById("labelpassword").style.visibility="visible";
            return false;
        }
        
        else {
            return true
            }
        }


function signup() {
    var signUpUserName = document.getElementById("signupusername");
    var signUpPassWord1 = document.getElementById("signuppassword1");
    var signUpPassWord2 = document.getElementById("signuppassword2");
    
        if (signUpUserName.value.trim() == ""){
            signUpUserName.style.border = "1px solid red";
            document.getElementById("labelsignupuser").style.visibility="visible";
            return false;
        }
    
    
        else if (signUpPassWord1.value.trim() == ""){
            signUpPassWord1.style.border = "1px solid red";
            document.getElementById("labelsignuppassword").style.visibility="visible";
            return false;
        }
    
        else if (signUpPassWord2.value.trim() == ""){
            signUpPassWord2.style.border = "1px solid red";
            document.getElementById("labelsignuppassword2").style.visibility="visible";
            return false;
        }
        else if (signUpPassWord1.value.trim() !== signUpPassWord2.value.trim()){
            signUpPassWord1.style.border = "1px solid red";
            document.getElementById("labelconfirmpassword").style.visibility="visible";
            return false;
        }
}

    function togglesignin() {
        document.querySelector(".signin-overlay").classList.toggle("open");
    }

    function togglesignup() {
        document.querySelector(".signup-overlay").classList.toggle("open");
    }
 //end sign in and sign up


// downloading
function downloading() {
    document.querySelector(".downloading-overlay").classList.toggle("open");
}
//end dowloading

//search function
function searchFunction() {
    var input, filter, ul, li, a, i;
    
    input = document.getElementById("search");
    filter = input.value.toUpperCase();
    ul = document.getElementById("wrapper");
    li = ul.getElementsByTagName("li");
    
    for(i=0; i < li.length; i++) {
        var a = li[i].getElementsByTagName("a")[0];
        if(a.innerHTML.toUpperCase().indexOf(filter) > -1){
            li[i].style.display = "";
        }else {
            li[i].style.display = "none";
        }
    }
}
//end search function